"""
EUREKA Undergraduate Tier Service

Features for undergraduate education:
- Lab simulations and templates
- Peer review system
- Code grading and analysis
- LTI 1.3 integration
- Project collaboration
- Research skills development

Compliance: FERPA, ABET
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

from app.config import settings
from app.database import engine, Base
from app.api.v1 import router as api_router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan"""
    logger.info(f"Starting {settings.SERVICE_NAME}...")
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    logger.info(f"{settings.SERVICE_NAME} started on port {settings.PORT}")
    yield
    
    logger.info(f"Shutting down {settings.SERVICE_NAME}...")
    await engine.dispose()


app = FastAPI(
    title="EUREKA Undergraduate API",
    description="Undergraduate education platform with labs, peer review, and project collaboration",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api/v1/undergraduate")


@app.get("/health")
async def health_check():
    return {
        "service": settings.SERVICE_NAME,
        "status": "healthy",
        "version": "1.0.0"
    }


@app.get("/")
async def root():
    return {
        "service": "EUREKA Undergraduate Tier",
        "version": "1.0.0",
        "documentation": "/docs"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=settings.PORT, reload=settings.DEBUG)
