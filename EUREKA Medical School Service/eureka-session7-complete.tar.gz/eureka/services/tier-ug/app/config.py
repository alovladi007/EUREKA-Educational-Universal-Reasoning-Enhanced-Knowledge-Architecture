"""Undergraduate Tier Configuration"""
from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    SERVICE_NAME: str = "undergraduate-tier"
    PORT: int = 8011
    DEBUG: bool = True
    DATABASE_URL: str = "postgresql+asyncpg://eureka:eureka_dev_password@localhost:5432/eureka"
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:8000"]
    
    # Features
    LTI_ENABLED: bool = True
    PEER_REVIEW_ENABLED: bool = True
    LAB_SIMULATIONS: bool = True
    CODE_GRADING: bool = True
    
    class Config:
        env_file = ".env"

settings = Settings()
