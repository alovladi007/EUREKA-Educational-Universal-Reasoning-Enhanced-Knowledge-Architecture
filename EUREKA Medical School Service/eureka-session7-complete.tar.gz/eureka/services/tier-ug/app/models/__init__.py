"""Undergraduate Tier Models"""
from sqlalchemy import Column, String, Integer, Boolean, DateTime, ForeignKey, JSON, Text, Float
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy.sql import func
from uuid import uuid4
from app.database import Base


class LabTemplate(Base):
    """Laboratory templates and simulations"""
    __tablename__ = "ug_lab_templates"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    subject = Column(String(100))
    difficulty_level = Column(String(50))
    estimated_duration_minutes = Column(Integer)
    objectives = Column(ARRAY(String))
    materials_required = Column(JSON)
    procedure_steps = Column(JSON)
    safety_notes = Column(Text)
    grading_rubric = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    is_active = Column(Boolean, default=True)


class PeerReview(Base):
    """Peer review submissions"""
    __tablename__ = "ug_peer_reviews"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    assignment_id = Column(UUID(as_uuid=True), nullable=False)
    reviewer_id = Column(UUID(as_uuid=True), nullable=False)
    reviewee_id = Column(UUID(as_uuid=True), nullable=False)
    submission_id = Column(UUID(as_uuid=True))
    
    # Review Content
    overall_score = Column(Float)
    strengths = Column(Text)
    areas_for_improvement = Column(Text)
    detailed_feedback = Column(JSON)
    
    # Status
    status = Column(String(50), default="pending")
    submitted_at = Column(DateTime(timezone=True), server_default=func.now())
    is_anonymous = Column(Boolean, default=True)


class CodeSubmission(Base):
    """Code assignments and submissions"""
    __tablename__ = "ug_code_submissions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    assignment_id = Column(UUID(as_uuid=True), nullable=False)
    student_id = Column(UUID(as_uuid=True), nullable=False)
    
    # Code
    code_content = Column(Text)
    language = Column(String(50))
    files = Column(JSON)  # Multiple files for projects
    
    # Grading
    test_results = Column(JSON)
    style_score = Column(Float)
    correctness_score = Column(Float)
    efficiency_score = Column(Float)
    overall_score = Column(Float)
    
    # Feedback
    automated_feedback = Column(JSON)
    instructor_feedback = Column(Text)
    
    # Status
    status = Column(String(50), default="submitted")
    submitted_at = Column(DateTime(timezone=True), server_default=func.now())
    graded_at = Column(DateTime(timezone=True))


class ProjectCollaboration(Base):
    """Group project collaboration"""
    __tablename__ = "ug_project_collaborations"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    project_name = Column(String(255), nullable=False)
    course_id = Column(UUID(as_uuid=True))
    description = Column(Text)
    
    # Team
    team_members = Column(ARRAY(UUID(as_uuid=True)))
    team_leader_id = Column(UUID(as_uuid=True))
    
    # Project Details
    milestones = Column(JSON)
    deliverables = Column(JSON)
    resources = Column(JSON)
    
    # Status
    status = Column(String(50), default="active")
    progress_percentage = Column(Float, default=0.0)
    
    # Timeline
    start_date = Column(DateTime(timezone=True))
    due_date = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class LTIIntegration(Base):
    """LTI 1.3 integration records"""
    __tablename__ = "ug_lti_integrations"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    platform_name = Column(String(255))
    client_id = Column(String(255))
    deployment_id = Column(String(255))
    
    # Configuration
    auth_endpoint = Column(String(500))
    token_endpoint = Column(String(500))
    keyset_url = Column(String(500))
    
    # Status
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
