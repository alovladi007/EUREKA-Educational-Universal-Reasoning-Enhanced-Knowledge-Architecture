"""
EUREKA Graduate Tier Service

Features for graduate education:
- Literature review tools
- Research methodology guidance
- Statistical analysis support
- Thesis/dissertation outline generation
- Citation management
- IRB compliance
- Data visualization

Compliance: FERPA, IRB
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

from app.config import settings
from app.database import engine, Base
from app.api.v1 import router as api_router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info(f"Starting {settings.SERVICE_NAME}...")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info(f"{settings.SERVICE_NAME} started on port {settings.PORT}")
    yield
    logger.info(f"Shutting down {settings.SERVICE_NAME}...")
    await engine.dispose()


app = FastAPI(
    title="EUREKA Graduate API",
    description="Graduate education platform with research tools and thesis support",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix="/api/v1/graduate")


@app.get("/health")
async def health_check():
    return {
        "service": settings.SERVICE_NAME,
        "status": "healthy",
        "version": "1.0.0"
    }


@app.get("/")
async def root():
    return {
        "service": "EUREKA Graduate Tier",
        "version": "1.0.0",
        "documentation": "/docs"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=settings.PORT, reload=settings.DEBUG)
