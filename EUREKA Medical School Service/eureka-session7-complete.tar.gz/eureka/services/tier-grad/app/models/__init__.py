"""Graduate Tier Models"""
from sqlalchemy import Column, String, Integer, Boolean, DateTime, ForeignKey, JSON, Text, Float
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy.sql import func
from uuid import uuid4
from app.database import Base


class LiteratureReview(Base):
    """Literature review database"""
    __tablename__ = "grad_literature_reviews"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    student_id = Column(UUID(as_uuid=True), nullable=False)
    title = Column(String(500), nullable=False)
    
    # Review Content
    research_question = Column(Text)
    keywords = Column(ARRAY(String))
    databases_searched = Column(ARRAY(String))
    sources = Column(JSON)  # Bibliography
    themes = Column(JSON)
    gaps_identified = Column(JSON)
    synthesis = Column(Text)
    
    # Status
    status = Column(String(50), default="draft")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class ResearchProposal(Base):
    """Research proposals and methodologies"""
    __tablename__ = "grad_research_proposals"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    student_id = Column(UUID(as_uuid=True), nullable=False)
    title = Column(String(500), nullable=False)
    
    # Proposal Sections
    abstract = Column(Text)
    introduction = Column(Text)
    literature_review_id = Column(UUID(as_uuid=True))
    research_questions = Column(JSON)
    hypotheses = Column(JSON)
    methodology = Column(JSON)
    expected_outcomes = Column(Text)
    timeline = Column(JSON)
    budget = Column(JSON)
    
    # IRB
    irb_status = Column(String(50))
    irb_approval_date = Column(DateTime(timezone=True))
    ethical_considerations = Column(Text)
    
    # Status
    status = Column(String(50), default="draft")
    submitted_at = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class ThesisChapter(Base):
    """Thesis/dissertation chapters"""
    __tablename__ = "grad_thesis_chapters"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    student_id = Column(UUID(as_uuid=True), nullable=False)
    chapter_number = Column(Integer)
    chapter_title = Column(String(500))
    
    # Content
    content = Column(Text)
    outline = Column(JSON)
    word_count = Column(Integer)
    
    # Feedback
    advisor_feedback = Column(JSON)
    peer_feedback = Column(JSON)
    revision_history = Column(JSON)
    
    # Status
    status = Column(String(50), default="draft")
    last_edited = Column(DateTime(timezone=True), onupdate=func.now())
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class StatisticalAnalysis(Base):
    """Statistical analysis records"""
    __tablename__ = "grad_statistical_analyses"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    student_id = Column(UUID(as_uuid=True), nullable=False)
    analysis_name = Column(String(255))
    
    # Analysis Details
    dataset_name = Column(String(255))
    variables = Column(JSON)
    test_type = Column(String(100))
    parameters = Column(JSON)
    
    # Results
    results = Column(JSON)
    interpretation = Column(Text)
    visualizations = Column(JSON)
    
    # Metadata
    software_used = Column(String(100))
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Citation(Base):
    """Citation management"""
    __tablename__ = "grad_citations"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    student_id = Column(UUID(as_uuid=True), nullable=False)
    
    # Citation Details
    citation_type = Column(String(50))  # book, journal, web, etc.
    authors = Column(JSON)
    title = Column(String(500))
    year = Column(Integer)
    publication = Column(String(500))
    doi = Column(String(255))
    url = Column(String(1000))
    
    # Formatted Citations
    apa_format = Column(Text)
    mla_format = Column(Text)
    chicago_format = Column(Text)
    bibtex = Column(Text)
    
    # Organization
    collections = Column(ARRAY(String))
    tags = Column(ARRAY(String))
    notes = Column(Text)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
