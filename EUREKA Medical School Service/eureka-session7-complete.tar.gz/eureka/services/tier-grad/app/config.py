"""Graduate Tier Configuration"""
from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    SERVICE_NAME: str = "graduate-tier"
    PORT: int = 8012
    DEBUG: bool = True
    DATABASE_URL: str = "postgresql+asyncpg://eureka:eureka_dev_password@localhost:5432/eureka"
    CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:8000"]
    
    # Features
    LITERATURE_REVIEW: bool = True
    RESEARCH_METHODS: bool = True
    STATISTICAL_ANALYSIS: bool = True
    THESIS_SUPPORT: bool = True
    IRB_COMPLIANCE: bool = True
    
    class Config:
        env_file = ".env"

settings = Settings()
