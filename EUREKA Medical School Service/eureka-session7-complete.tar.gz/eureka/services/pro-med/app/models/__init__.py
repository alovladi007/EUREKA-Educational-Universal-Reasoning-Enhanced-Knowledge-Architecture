"""
Medical School Tier - Database Models

Models for medical education features with HIPAA compliance.
"""

from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, ForeignKey, JSON, Text
from sqlalchemy.dialects.postgresql import UUID, ARRAY
from sqlalchemy.sql import func
from uuid import uuid4

from app.database import Base


class ClinicalCase(Base):
    """Clinical case simulations"""
    __tablename__ = "medical_clinical_cases"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    
    # Case Details
    patient_age = Column(Integer)
    patient_gender = Column(String(20))
    chief_complaint = Column(Text)
    history_present_illness = Column(Text)
    past_medical_history = Column(JSON)
    medications = Column(JSON)
    allergies = Column(ARRAY(String))
    social_history = Column(JSON)
    family_history = Column(JSON)
    
    # Physical Exam
    vital_signs = Column(JSON)
    physical_exam_findings = Column(JSON)
    
    # Diagnostic Data
    lab_results = Column(JSON)
    imaging_results = Column(JSON)
    other_tests = Column(JSON)
    
    # Case Metadata
    specialty = Column(String(100))
    complexity_level = Column(String(50))  # MS1, MS2, MS3, MS4, Resident
    learning_objectives = Column(ARRAY(String))
    keywords = Column(ARRAY(String))
    
    # Answers
    correct_diagnosis = Column(String(255))
    differential_diagnosis = Column(JSON)
    treatment_plan = Column(JSON)
    expected_outcome = Column(Text)
    
    # Usage
    difficulty_rating = Column(Float, default=3.0)
    completion_time_minutes = Column(Integer, default=30)
    times_used = Column(Integer, default=0)
    avg_score = Column(Float)
    
    # Compliance
    phi_removed = Column(Boolean, default=True)
    consent_obtained = Column(Boolean, default=True)
    
    # Metadata
    created_by = Column(UUID(as_uuid=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    is_active = Column(Boolean, default=True)


class USMLEQuestion(Base):
    """USMLE practice questions"""
    __tablename__ = "medical_usmle_questions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Question Content
    question_text = Column(Text, nullable=False)
    question_type = Column(String(50))  # single_best, multiple_select, case_based
    stem = Column(Text)  # For multi-part questions
    
    # Answer Options
    options = Column(JSON, nullable=False)  # List of answer choices
    correct_answer = Column(String(10), nullable=False)  # A, B, C, D, E
    correct_answer_ids = Column(ARRAY(String))  # For multiple correct answers
    
    # Explanation
    explanation = Column(Text)
    educational_objective = Column(Text)
    references = Column(JSON)  # Citations and sources
    
    # Classification
    exam_type = Column(String(50))  # Step 1, Step 2 CK, Step 3
    subject = Column(String(100))  # Anatomy, Physiology, Pathology, etc.
    system = Column(String(100))  # Cardiovascular, Respiratory, etc.
    topic = Column(String(255))
    subtopic = Column(String(255))
    
    # Difficulty
    difficulty_level = Column(String(50))
    bloom_taxonomy_level = Column(String(50))  # Remember, Understand, Apply, Analyze
    
    # Statistics
    times_answered = Column(Integer, default=0)
    times_correct = Column(Integer, default=0)
    avg_time_seconds = Column(Integer)
    discrimination_index = Column(Float)
    
    # Metadata
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    is_active = Column(Boolean, default=True)


class CaseSubmission(Base):
    """Student clinical case submissions"""
    __tablename__ = "medical_case_submissions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    user_id = Column(UUID(as_uuid=True), nullable=False)
    case_id = Column(UUID(as_uuid=True), ForeignKey("medical_clinical_cases.id"))
    
    # Student's Work
    submitted_diagnosis = Column(String(255))
    differential_diagnosis = Column(JSON)
    reasoning = Column(Text)
    treatment_plan = Column(JSON)
    
    # Scoring
    diagnosis_correct = Column(Boolean)
    differential_quality_score = Column(Float)
    reasoning_score = Column(Float)
    treatment_score = Column(Float)
    overall_score = Column(Float)
    
    # Feedback
    ai_feedback = Column(Text)
    instructor_feedback = Column(Text)
    
    # Timing
    started_at = Column(DateTime(timezone=True))
    submitted_at = Column(DateTime(timezone=True), server_default=func.now())
    time_spent_minutes = Column(Integer)
    
    # Status
    status = Column(String(50), default="submitted")  # submitted, graded, reviewed
    graded_at = Column(DateTime(timezone=True))
    reviewed_at = Column(DateTime(timezone=True))


class Anatomy3DModel(Base):
    """3D anatomy model references"""
    __tablename__ = "medical_anatomy_models"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    
    # Model Details
    body_system = Column(String(100))  # Cardiovascular, Respiratory, etc.
    structure_name = Column(String(255))
    model_url = Column(String(500))
    thumbnail_url = Column(String(500))
    
    # Interactive Features
    interactive_layers = Column(JSON)
    labels = Column(JSON)
    animations = Column(JSON)
    
    # Educational Content
    clinical_relevance = Column(Text)
    common_pathologies = Column(JSON)
    related_cases = Column(ARRAY(UUID(as_uuid=True)))
    
    # Metadata
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    is_active = Column(Boolean, default=True)


class PharmacologyEntry(Base):
    """Pharmacology database"""
    __tablename__ = "medical_pharmacology"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Drug Information
    generic_name = Column(String(255), nullable=False)
    brand_names = Column(ARRAY(String))
    drug_class = Column(String(100))
    
    # Mechanism
    mechanism_of_action = Column(Text)
    pharmacokinetics = Column(JSON)  # Absorption, Distribution, Metabolism, Excretion
    pharmacodynamics = Column(JSON)
    
    # Clinical Use
    indications = Column(JSON)
    contraindications = Column(JSON)
    dosing = Column(JSON)
    
    # Safety
    adverse_effects = Column(JSON)
    black_box_warnings = Column(ARRAY(String))
    drug_interactions = Column(JSON)
    pregnancy_category = Column(String(10))
    
    # Monitoring
    required_monitoring = Column(JSON)
    therapeutic_range = Column(JSON)
    
    # Metadata
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


class OSCEStation(Base):
    """OSCE (Objective Structured Clinical Examination) stations"""
    __tablename__ = "medical_osce_stations"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    
    # Station Configuration
    station_type = Column(String(100))  # History, Physical Exam, Communication, Procedure
    duration_minutes = Column(Integer, default=10)
    
    # Scenario
    patient_scenario = Column(Text)
    standardized_patient_instructions = Column(Text)
    
    # Competencies Being Tested
    competencies = Column(ARRAY(String))
    skills_assessed = Column(ARRAY(String))
    
    # Checklist
    checklist_items = Column(JSON)
    required_items = Column(ARRAY(String))
    critical_actions = Column(ARRAY(String))
    
    # Scoring
    max_score = Column(Integer)
    passing_score = Column(Integer)
    
    # Metadata
    specialty = Column(String(100))
    difficulty_level = Column(String(50))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    is_active = Column(Boolean, default=True)


class StudentProgress(Base):
    """Track student progress in medical curriculum"""
    __tablename__ = "medical_student_progress"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid4)
    user_id = Column(UUID(as_uuid=True), nullable=False, unique=True)
    
    # Academic Year
    medical_school_year = Column(Integer)  # 1, 2, 3, 4
    
    # USMLE Progress
    usmle_step1_score = Column(Integer)
    usmle_step1_date = Column(DateTime(timezone=True))
    usmle_step2_ck_score = Column(Integer)
    usmle_step2_ck_date = Column(DateTime(timezone=True))
    usmle_step3_score = Column(Integer)
    usmle_step3_date = Column(DateTime(timezone=True))
    
    # Practice Stats
    total_questions_answered = Column(Integer, default=0)
    correct_answers = Column(Integer, default=0)
    total_cases_completed = Column(Integer, default=0)
    avg_case_score = Column(Float)
    
    # Subject Mastery
    subject_scores = Column(JSON)  # Scores by subject area
    weak_areas = Column(ARRAY(String))
    strong_areas = Column(ARRAY(String))
    
    # Study Time
    total_study_hours = Column(Float, default=0.0)
    last_study_date = Column(DateTime(timezone=True))
    study_streak_days = Column(Integer, default=0)
    
    # Goals
    target_step1_score = Column(Integer)
    target_step1_date = Column(DateTime(timezone=True))
    weekly_question_goal = Column(Integer)
    
    # Metadata
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
