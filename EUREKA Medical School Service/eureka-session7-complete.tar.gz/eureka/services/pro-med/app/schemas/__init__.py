"""
Medical School Tier - Pydantic Schemas
"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from uuid import UUID


# Clinical Cases
class ClinicalCaseCreate(BaseModel):
    title: str
    description: str
    patient_age: Optional[int] = None
    patient_gender: Optional[str] = None
    chief_complaint: str
    specialty: str
    complexity_level: str
    correct_diagnosis: str


class ClinicalCaseResponse(BaseModel):
    id: UUID
    title: str
    specialty: str
    complexity_level: str
    difficulty_rating: float
    completion_time_minutes: int
    
    class Config:
        from_attributes = True


class ClinicalCaseDetail(ClinicalCaseResponse):
    description: str
    patient_age: Optional[int]
    patient_gender: Optional[str]
    chief_complaint: str
    history_present_illness: Optional[str]
    vital_signs: Optional[Dict]
    physical_exam_findings: Optional[Dict]
    lab_results: Optional[Dict]
    learning_objectives: Optional[List[str]]


# Case Submissions
class CaseSubmissionCreate(BaseModel):
    submitted_diagnosis: str
    differential_diagnosis: List[str]
    reasoning: str
    treatment_plan: Dict


class CaseSubmissionResponse(BaseModel):
    id: UUID
    diagnosis_correct: bool
    overall_score: float
    ai_feedback: str
    submitted_at: datetime
    
    class Config:
        from_attributes = True


# USMLE
class USMLEQuestionResponse(BaseModel):
    id: UUID
    question_text: str
    options: Dict
    exam_type: str
    subject: str
    difficulty_level: str
    
    class Config:
        from_attributes = True


class USMLEAnswerSubmit(BaseModel):
    answer: str
    time_spent_seconds: int


class USMLEAnswerResponse(BaseModel):
    is_correct: bool
    correct_answer: str
    explanation: str
    educational_objective: str


class USMLEProgressResponse(BaseModel):
    total_questions: int
    correct_answers: int
    accuracy_rate: float
    subject_scores: Dict[str, float]
    weak_areas: List[str]
    strong_areas: List[str]


# OSCE
class OSCEStationResponse(BaseModel):
    id: UUID
    title: str
    station_type: str
    duration_minutes: int
    difficulty_level: str
    
    class Config:
        from_attributes = True


class OSCEStationDetail(OSCEStationResponse):
    description: str
    patient_scenario: str
    competencies: List[str]
    skills_assessed: List[str]
    checklist_items: Dict


class OSCECompletionCreate(BaseModel):
    checklist_completed: Dict[str, bool]
    time_spent_minutes: int
    notes: Optional[str] = None


class OSCECompletionResponse(BaseModel):
    checklist_score: float
    critical_actions_completed: int
    overall_score: float
    feedback: str


# Anatomy
class AnatomyModelResponse(BaseModel):
    id: UUID
    name: str
    body_system: str
    thumbnail_url: str
    
    class Config:
        from_attributes = True


class AnatomyModelDetail(AnatomyModelResponse):
    description: str
    model_url: str
    interactive_layers: Dict
    labels: Dict
    clinical_relevance: str


# Pharmacology
class PharmacologyEntryResponse(BaseModel):
    id: UUID
    generic_name: str
    brand_names: List[str]
    drug_class: str
    
    class Config:
        from_attributes = True


class PharmacologyDetail(PharmacologyEntryResponse):
    mechanism_of_action: str
    indications: Dict
    adverse_effects: Dict
    dosing: Dict
    drug_interactions: Dict


# Progress
class StudentProgressResponse(BaseModel):
    user_id: UUID
    medical_school_year: int
    total_questions_answered: int
    correct_answers: int
    accuracy_rate: float
    total_cases_completed: int
    avg_case_score: Optional[float]
    study_streak_days: int
    
    class Config:
        from_attributes = True


class StudentProgressUpdate(BaseModel):
    medical_school_year: Optional[int] = None
    target_step1_score: Optional[int] = None
    weekly_question_goal: Optional[int] = None


# Diagnostic Reasoning
class DifferentialDiagnosisRequest(BaseModel):
    chief_complaint: str
    history: str
    physical_exam: Dict
    labs: Optional[Dict] = None
    imaging: Optional[Dict] = None


class DifferentialDiagnosisResponse(BaseModel):
    diagnoses: List[Dict[str, Any]]
    reasoning: str
    confidence_scores: Dict[str, float]
    recommended_tests: List[str]


class DiagnosticRequest(BaseModel):
    current_findings: Dict
    working_diagnosis: Optional[str] = None


class NextStepsResponse(BaseModel):
    recommended_history: List[str]
    recommended_exam: List[str]
    recommended_labs: List[str]
    recommended_imaging: List[str]
    reasoning: str
