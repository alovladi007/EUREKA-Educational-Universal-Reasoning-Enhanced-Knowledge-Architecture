"""
Medical School Tier Configuration

Settings for professional medical education tier with HIPAA compliance.
"""

from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    """Medical School tier settings"""
    
    # Service Configuration
    SERVICE_NAME: str = "medical-school"
    PORT: int = 8020
    DEBUG: bool = True
    ENVIRONMENT: str = "development"
    
    # Database
    DATABASE_URL: str = "postgresql+asyncpg://eureka:eureka_dev_password@localhost:5432/eureka"
    
    # CORS
    CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:8000",
        "http://localhost:4500"
    ]
    
    # HIPAA Compliance
    HIPAA_MODE: bool = True
    PHI_PROTECTION: str = "maximum"
    DE_IDENTIFICATION: bool = True
    AUDIT_LOGGING: str = "comprehensive"
    
    # Medical Education Features
    USMLE_MODE: bool = True
    CLINICAL_CASES: bool = True
    ANATOMY_3D: bool = True
    PHARMACOLOGY_DB: bool = True
    
    # AI Integration
    OPENAI_API_KEY: str = ""
    ANTHROPIC_API_KEY: str = ""
    AI_MODEL: str = "gpt-4-turbo-preview"
    AI_TEMPERATURE: float = 0.7
    
    # Clinical Reasoning
    DIFFERENTIAL_DX_ENGINE: bool = True
    BAYESIAN_REASONING: bool = True
    EVIDENCE_BASED_FEEDBACK: bool = True
    
    # Assessment Configuration
    USMLE_QUESTION_POOL_SIZE: int = 10000
    CLINICAL_CASE_POOL_SIZE: int = 500
    OSCE_STATIONS: int = 12
    
    # Session Configuration
    MAX_SESSION_LENGTH_MINUTES: int = 180
    CASE_COMPLEXITY_LEVELS: List[str] = [
        "medical_student",
        "intern",
        "resident",
        "attending"
    ]
    
    # Content Limits
    MAX_CASE_LENGTH: int = 2000
    MAX_DIAGNOSIS_OPTIONS: int = 15
    MAX_LAB_RESULTS: int = 50
    
    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
