"""
File Upload Endpoints

Handles file uploads for various purposes:
- Student assignment submissions
- Course materials (PDFs, videos, images)
- Profile pictures
- Documents and resources
"""

from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, Form
from fastapi.responses import FileResponse, StreamingResponse
from typing import List, Optional
from uuid import UUID, uuid4
from datetime import datetime
import shutil
import os
from pathlib import Path
import mimetypes

from app.api.dependencies import get_current_user, require_permission
from app.models import User
from app.schemas.file import (
    FileUploadResponse,
    FileListResponse,
    FileMetadata,
    FileUpdate
)

router = APIRouter(prefix="/files", tags=["files"])

# Configuration
UPLOAD_DIR = Path("/mnt/user-data/uploads")
MAX_FILE_SIZE = 100 * 1024 * 1024  # 100MB
ALLOWED_EXTENSIONS = {
    'image': ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'],
    'document': ['.pdf', '.doc', '.docx', '.txt', '.md', '.rtf'],
    'video': ['.mp4', '.mov', '.avi', '.mkv', '.webm'],
    'audio': ['.mp3', '.wav', '.ogg', '.m4a'],
    'archive': ['.zip', '.tar', '.gz', '.rar'],
    'code': ['.py', '.js', '.java', '.cpp', '.html', '.css']
}

# Ensure upload directory exists
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


def get_file_category(filename: str) -> str:
    """Determine file category based on extension"""
    ext = Path(filename).suffix.lower()
    for category, extensions in ALLOWED_EXTENSIONS.items():
        if ext in extensions:
            return category
    return 'other'


def is_allowed_file(filename: str) -> bool:
    """Check if file extension is allowed"""
    ext = Path(filename).suffix.lower()
    return any(ext in exts for exts in ALLOWED_EXTENSIONS.values())


async def save_upload_file(upload_file: UploadFile, destination: Path) -> int:
    """Save uploaded file to destination and return file size"""
    file_size = 0
    with destination.open("wb") as buffer:
        while chunk := await upload_file.read(8192):  # 8KB chunks
            file_size += len(chunk)
            if file_size > MAX_FILE_SIZE:
                destination.unlink()  # Delete partial file
                raise HTTPException(
                    status_code=413,
                    detail=f"File too large. Maximum size is {MAX_FILE_SIZE / 1024 / 1024}MB"
                )
            buffer.write(chunk)
    return file_size


@router.post("/upload", response_model=FileUploadResponse)
async def upload_file(
    file: UploadFile = File(...),
    category: Optional[str] = Form(None),
    description: Optional[str] = Form(None),
    course_id: Optional[UUID] = Form(None),
    assignment_id: Optional[UUID] = Form(None),
    current_user: User = Depends(get_current_user)
):
    """
    Upload a file
    
    **Supports:**
    - Images (profile pictures, course thumbnails)
    - Documents (assignments, course materials)
    - Videos (lectures, tutorials)
    - Audio (podcasts, recordings)
    - Code files (programming assignments)
    
    **Access:** Authenticated users
    """
    # Validate file
    if not file.filename:
        raise HTTPException(status_code=400, detail="No filename provided")
    
    if not is_allowed_file(file.filename):
        raise HTTPException(
            status_code=400,
            detail=f"File type not allowed. Allowed types: {', '.join(sum(ALLOWED_EXTENSIONS.values(), []))}"
        )
    
    # Generate unique filename
    file_ext = Path(file.filename).suffix
    unique_filename = f"{uuid4()}{file_ext}"
    file_path = UPLOAD_DIR / str(current_user.org_id) / str(current_user.id) / unique_filename
    
    # Create directory structure
    file_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Save file
    try:
        file_size = await save_upload_file(file, file_path)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save file: {str(e)}")
    
    # Determine category if not provided
    if not category:
        category = get_file_category(file.filename)
    
    # Get MIME type
    mime_type = mimetypes.guess_type(file.filename)[0] or 'application/octet-stream'
    
    # Create file metadata
    file_metadata = FileMetadata(
        id=uuid4(),
        user_id=current_user.id,
        org_id=current_user.org_id,
        filename=file.filename,
        unique_filename=unique_filename,
        file_path=str(file_path),
        file_size=file_size,
        mime_type=mime_type,
        category=category,
        description=description,
        course_id=course_id,
        assignment_id=assignment_id,
        uploaded_at=datetime.utcnow()
    )
    
    # TODO: Save metadata to database
    
    return FileUploadResponse(
        id=file_metadata.id,
        filename=file.filename,
        file_size=file_size,
        mime_type=mime_type,
        category=category,
        url=f"/api/v1/files/{file_metadata.id}/download",
        uploaded_at=file_metadata.uploaded_at
    )


@router.post("/upload-multiple", response_model=List[FileUploadResponse])
async def upload_multiple_files(
    files: List[UploadFile] = File(...),
    category: Optional[str] = Form(None),
    course_id: Optional[UUID] = Form(None),
    current_user: User = Depends(get_current_user)
):
    """
    Upload multiple files at once
    
    **Useful for:**
    - Batch course material uploads
    - Multiple assignment submissions
    - Image galleries
    
    **Access:** Authenticated users
    """
    if len(files) > 10:
        raise HTTPException(status_code=400, detail="Maximum 10 files allowed per upload")
    
    results = []
    for file in files:
        try:
            result = await upload_file(
                file=file,
                category=category,
                course_id=course_id,
                current_user=current_user
            )
            results.append(result)
        except HTTPException as e:
            # Continue with other files even if one fails
            results.append({
                "filename": file.filename,
                "error": e.detail
            })
    
    return results


@router.get("/{file_id}/download")
async def download_file(
    file_id: UUID,
    current_user: User = Depends(get_current_user)
):
    """
    Download a file
    
    **Access:** File owner or authorized users
    """
    # TODO: Get file metadata from database
    # For now, return a 404
    raise HTTPException(status_code=404, detail="File not found")


@router.get("/{file_id}", response_model=FileMetadata)
async def get_file_metadata(
    file_id: UUID,
    current_user: User = Depends(get_current_user)
):
    """
    Get file metadata
    
    **Returns:**
    - Filename, size, type
    - Upload date
    - Associated course/assignment
    - Download URL
    
    **Access:** File owner or authorized users
    """
    # TODO: Get file metadata from database
    raise HTTPException(status_code=404, detail="File not found")


@router.get("/", response_model=FileListResponse)
async def list_files(
    category: Optional[str] = None,
    course_id: Optional[UUID] = None,
    assignment_id: Optional[UUID] = None,
    page: int = 1,
    page_size: int = 20,
    current_user: User = Depends(get_current_user)
):
    """
    List user's uploaded files
    
    **Filters:**
    - Category (image, document, video, etc.)
    - Course
    - Assignment
    
    **Access:** Authenticated users (own files only)
    """
    # TODO: Query database with filters
    return FileListResponse(
        data=[],
        total=0,
        page=page,
        page_size=page_size
    )


@router.delete("/{file_id}")
async def delete_file(
    file_id: UUID,
    current_user: User = Depends(get_current_user)
):
    """
    Delete a file
    
    **Access:** File owner or admin
    """
    # TODO: Get file metadata from database
    # TODO: Check permissions
    # TODO: Delete file from filesystem
    # TODO: Delete metadata from database
    raise HTTPException(status_code=404, detail="File not found")


@router.put("/{file_id}", response_model=FileMetadata)
async def update_file_metadata(
    file_id: UUID,
    file_update: FileUpdate,
    current_user: User = Depends(get_current_user)
):
    """
    Update file metadata (description, category, etc.)
    
    **Access:** File owner or admin
    """
    # TODO: Get file metadata from database
    # TODO: Check permissions
    # TODO: Update metadata
    raise HTTPException(status_code=404, detail="File not found")


# Profile Picture Specific Endpoints

@router.post("/profile-picture", response_model=FileUploadResponse)
async def upload_profile_picture(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    Upload profile picture
    
    **Restrictions:**
    - Images only (JPG, PNG, GIF, WebP)
    - Maximum 5MB
    - Automatically resized to 500x500
    
    **Access:** Authenticated users
    """
    # Validate image
    if not any(file.filename.lower().endswith(ext) for ext in ALLOWED_EXTENSIONS['image']):
        raise HTTPException(status_code=400, detail="Only image files allowed for profile pictures")
    
    # TODO: Resize image to 500x500
    # TODO: Save as profile picture
    # TODO: Update user profile
    
    return await upload_file(
        file=file,
        category="profile_picture",
        current_user=current_user
    )


# Assignment Submission Specific Endpoints

@router.post("/assignment-submission", response_model=FileUploadResponse)
async def submit_assignment(
    file: UploadFile = File(...),
    assignment_id: UUID = Form(...),
    comments: Optional[str] = Form(None),
    current_user: User = Depends(get_current_user)
):
    """
    Submit assignment file
    
    **Records:**
    - Submission time
    - Student comments
    - File metadata
    
    **Access:** Students only
    """
    # TODO: Validate assignment exists
    # TODO: Check submission deadline
    # TODO: Create submission record
    
    return await upload_file(
        file=file,
        category="assignment_submission",
        assignment_id=assignment_id,
        description=comments,
        current_user=current_user
    )


# Course Material Specific Endpoints

@router.post("/course-material", response_model=FileUploadResponse)
async def upload_course_material(
    file: UploadFile = File(...),
    course_id: UUID = Form(...),
    title: str = Form(...),
    description: Optional[str] = Form(None),
    current_user: User = Depends(require_permission("courses.manage"))
):
    """
    Upload course material
    
    **Supports:**
    - Lecture slides
    - Reading materials
    - Video lectures
    - Supplementary resources
    
    **Access:** Teachers and admins
    """
    # TODO: Validate course exists
    # TODO: Check user is teacher of course
    
    return await upload_file(
        file=file,
        category="course_material",
        course_id=course_id,
        description=description,
        current_user=current_user
    )
