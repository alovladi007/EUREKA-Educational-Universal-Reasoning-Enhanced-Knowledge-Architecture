"""
WebSocket Support for Real-Time Features

Enables:
- Live AI tutoring sessions
- Real-time notifications
- Chat/messaging
- Live class sessions
- Collaborative editing
- Progress updates
"""

from fastapi import WebSocket, WebSocketDisconnect, Depends
from typing import Dict, List, Set
from uuid import UUID
import json
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class ConnectionManager:
    """Manages WebSocket connections"""
    
    def __init__(self):
        # Active connections by user_id
        self.active_connections: Dict[str, Set[WebSocket]] = {}
        # Active connections by room_id (for group features)
        self.rooms: Dict[str, Set[WebSocket]] = {}
    
    async def connect(self, websocket: WebSocket, user_id: str):
        """Connect a user"""
        await websocket.accept()
        
        if user_id not in self.active_connections:
            self.active_connections[user_id] = set()
        
        self.active_connections[user_id].add(websocket)
        logger.info(f"User {user_id} connected. Total connections: {len(self.active_connections[user_id])}")
    
    def disconnect(self, websocket: WebSocket, user_id: str):
        """Disconnect a user"""
        if user_id in self.active_connections:
            self.active_connections[user_id].discard(websocket)
            
            # Remove user if no more connections
            if not self.active_connections[user_id]:
                del self.active_connections[user_id]
        
        logger.info(f"User {user_id} disconnected")
    
    async def send_personal_message(self, message: dict, user_id: str):
        """Send message to specific user (all their connections)"""
        if user_id in self.active_connections:
            disconnected = set()
            for connection in self.active_connections[user_id]:
                try:
                    await connection.send_json(message)
                except Exception as e:
                    logger.error(f"Error sending to {user_id}: {e}")
                    disconnected.add(connection)
            
            # Clean up dead connections
            for conn in disconnected:
                self.active_connections[user_id].discard(conn)
    
    async def broadcast(self, message: dict):
        """Broadcast message to all connected users"""
        for user_id in list(self.active_connections.keys()):
            await self.send_personal_message(message, user_id)
    
    async def join_room(self, websocket: WebSocket, room_id: str, user_id: str):
        """Join a room (for group features)"""
        if room_id not in self.rooms:
            self.rooms[room_id] = set()
        
        self.rooms[room_id].add(websocket)
        logger.info(f"User {user_id} joined room {room_id}")
        
        # Notify others in room
        await self.send_to_room(
            {
                "type": "user_joined",
                "user_id": user_id,
                "room_id": room_id,
                "timestamp": datetime.utcnow().isoformat()
            },
            room_id,
            exclude=websocket
        )
    
    async def leave_room(self, websocket: WebSocket, room_id: str, user_id: str):
        """Leave a room"""
        if room_id in self.rooms:
            self.rooms[room_id].discard(websocket)
            
            # Remove room if empty
            if not self.rooms[room_id]:
                del self.rooms[room_id]
        
        logger.info(f"User {user_id} left room {room_id}")
        
        # Notify others in room
        await self.send_to_room(
            {
                "type": "user_left",
                "user_id": user_id,
                "room_id": room_id,
                "timestamp": datetime.utcnow().isoformat()
            },
            room_id
        )
    
    async def send_to_room(self, message: dict, room_id: str, exclude: WebSocket = None):
        """Send message to all users in a room"""
        if room_id in self.rooms:
            disconnected = set()
            for connection in self.rooms[room_id]:
                if connection != exclude:
                    try:
                        await connection.send_json(message)
                    except Exception as e:
                        logger.error(f"Error sending to room {room_id}: {e}")
                        disconnected.add(connection)
            
            # Clean up dead connections
            for conn in disconnected:
                self.rooms[room_id].discard(conn)


# Global connection manager
manager = ConnectionManager()


# WebSocket Routes

async def websocket_endpoint(websocket: WebSocket, user_id: str):
    """
    Main WebSocket endpoint
    
    **Usage:**
    ```javascript
    const ws = new WebSocket('ws://localhost:8000/ws/user123');
    
    ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        console.log('Received:', data);
    };
    
    ws.send(JSON.stringify({
        type: 'message',
        content: 'Hello!'
    }));
    ```
    """
    await manager.connect(websocket, user_id)
    
    try:
        while True:
            # Receive message from client
            data = await websocket.receive_text()
            message = json.loads(data)
            
            # Handle different message types
            message_type = message.get('type')
            
            if message_type == 'ping':
                # Heartbeat
                await websocket.send_json({
                    "type": "pong",
                    "timestamp": datetime.utcnow().isoformat()
                })
            
            elif message_type == 'join_room':
                # Join a room for group features
                room_id = message.get('room_id')
                if room_id:
                    await manager.join_room(websocket, room_id, user_id)
            
            elif message_type == 'leave_room':
                # Leave a room
                room_id = message.get('room_id')
                if room_id:
                    await manager.leave_room(websocket, room_id, user_id)
            
            elif message_type == 'chat_message':
                # Send chat message to room
                room_id = message.get('room_id')
                if room_id:
                    await manager.send_to_room(
                        {
                            "type": "chat_message",
                            "user_id": user_id,
                            "content": message.get('content'),
                            "timestamp": datetime.utcnow().isoformat()
                        },
                        room_id
                    )
            
            elif message_type == 'tutor_query':
                # AI tutor query (to be processed by AI service)
                await websocket.send_json({
                    "type": "tutor_response",
                    "query": message.get('query'),
                    "response": "AI response would go here",
                    "timestamp": datetime.utcnow().isoformat()
                })
            
            elif message_type == 'typing':
                # Typing indicator
                room_id = message.get('room_id')
                if room_id:
                    await manager.send_to_room(
                        {
                            "type": "typing",
                            "user_id": user_id,
                            "is_typing": message.get('is_typing', False)
                        },
                        room_id,
                        exclude=websocket
                    )
    
    except WebSocketDisconnect:
        manager.disconnect(websocket, user_id)
        logger.info(f"User {user_id} disconnected")
    
    except Exception as e:
        logger.error(f"WebSocket error for user {user_id}: {e}")
        manager.disconnect(websocket, user_id)


# Notification System

async def send_notification(user_id: str, notification: dict):
    """
    Send notification to user
    
    **Notification Types:**
    - grade_posted
    - assignment_due
    - message_received
    - badge_earned
    - course_update
    """
    await manager.send_personal_message(
        {
            "type": "notification",
            "notification": notification,
            "timestamp": datetime.utcnow().isoformat()
        },
        user_id
    )


async def broadcast_announcement(announcement: dict):
    """
    Broadcast announcement to all users
    
    **Use for:**
    - System maintenance
    - Platform updates
    - Emergency notifications
    """
    await manager.broadcast({
        "type": "announcement",
        "announcement": announcement,
        "timestamp": datetime.utcnow().isoformat()
    })


# Live Session Management

class LiveSession:
    """Manages live tutoring/class sessions"""
    
    def __init__(self, session_id: str, host_id: str):
        self.session_id = session_id
        self.host_id = host_id
        self.participants: Set[str] = set()
        self.room_id = f"session_{session_id}"
    
    async def add_participant(self, user_id: str, websocket: WebSocket):
        """Add participant to live session"""
        self.participants.add(user_id)
        await manager.join_room(websocket, self.room_id, user_id)
        
        # Notify all participants
        await manager.send_to_room(
            {
                "type": "participant_joined",
                "session_id": self.session_id,
                "user_id": user_id,
                "participant_count": len(self.participants)
            },
            self.room_id
        )
    
    async def remove_participant(self, user_id: str, websocket: WebSocket):
        """Remove participant from live session"""
        self.participants.discard(user_id)
        await manager.leave_room(websocket, self.room_id, user_id)
    
    async def send_to_session(self, message: dict):
        """Send message to all session participants"""
        await manager.send_to_room(message, self.room_id)


# Active sessions
active_sessions: Dict[str, LiveSession] = {}


async def create_live_session(session_id: str, host_id: str) -> LiveSession:
    """Create a new live session"""
    session = LiveSession(session_id, host_id)
    active_sessions[session_id] = session
    return session


async def end_live_session(session_id: str):
    """End a live session"""
    if session_id in active_sessions:
        session = active_sessions[session_id]
        
        # Notify all participants
        await session.send_to_session({
            "type": "session_ended",
            "session_id": session_id,
            "timestamp": datetime.utcnow().isoformat()
        })
        
        del active_sessions[session_id]


# Presence System

class PresenceManager:
    """Track user online status"""
    
    def __init__(self):
        self.online_users: Set[str] = set()
    
    def user_online(self, user_id: str):
        """Mark user as online"""
        self.online_users.add(user_id)
    
    def user_offline(self, user_id: str):
        """Mark user as offline"""
        self.online_users.discard(user_id)
    
    def is_online(self, user_id: str) -> bool:
        """Check if user is online"""
        return user_id in self.online_users
    
    def get_online_count(self) -> int:
        """Get count of online users"""
        return len(self.online_users)


presence_manager = PresenceManager()
