"""
File Upload Schemas

Pydantic models for file upload requests and responses.
"""

from pydantic import BaseModel, Field, HttpUrl
from typing import Optional, List
from datetime import datetime
from uuid import UUID


class FileMetadata(BaseModel):
    """Complete file metadata"""
    id: UUID
    user_id: UUID
    org_id: UUID
    filename: str
    unique_filename: str
    file_path: str
    file_size: int
    mime_type: str
    category: str
    description: Optional[str] = None
    course_id: Optional[UUID] = None
    assignment_id: Optional[UUID] = None
    uploaded_at: datetime
    
    class Config:
        from_attributes = True


class FileUploadResponse(BaseModel):
    """Response after successful file upload"""
    id: UUID
    filename: str
    file_size: int
    mime_type: str
    category: str
    url: str
    uploaded_at: datetime


class FileUpdate(BaseModel):
    """Schema for updating file metadata"""
    description: Optional[str] = None
    category: Optional[str] = None


class FileListResponse(BaseModel):
    """Paginated list of files"""
    data: List[FileMetadata]
    total: int
    page: int
    page_size: int


class AssignmentSubmission(BaseModel):
    """Assignment submission with file"""
    id: UUID
    assignment_id: UUID
    student_id: UUID
    file_id: UUID
    submitted_at: datetime
    comments: Optional[str] = None
    status: str = Field(..., description="submitted, graded, returned")
    grade: Optional[float] = None
    feedback: Optional[str] = None
    
    class Config:
        from_attributes = True


class CourseMateri al(BaseModel):
    """Course material file"""
    id: UUID
    course_id: UUID
    file_id: UUID
    title: str
    description: Optional[str] = None
    module_id: Optional[UUID] = None
    order: int = 0
    is_required: bool = True
    available_from: Optional[datetime] = None
    available_until: Optional[datetime] = None
    
    class Config:
        from_attributes = True
