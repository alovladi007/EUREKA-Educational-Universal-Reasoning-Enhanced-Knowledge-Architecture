'use client';

import { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Video, 
  FileText, 
  Download, 
  Search,
  Filter,
  Star,
  Clock,
  Tag
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';

interface Resource {
  id: string;
  title: string;
  description: string;
  type: 'document' | 'video' | 'article' | 'book';
  category: string;
  url: string;
  thumbnail?: string;
  author: string;
  createdAt: string;
  downloads: number;
  rating: number;
  tags: string[];
}

const mockResources: Resource[] = [
  {
    id: '1',
    title: 'Introduction to Calculus',
    description: 'Comprehensive guide to calculus fundamentals including limits, derivatives, and integrals',
    type: 'document',
    category: 'Mathematics',
    url: '#',
    author: 'Dr. Jane Smith',
    createdAt: '2024-10-15',
    downloads: 234,
    rating: 4.8,
    tags: ['calculus', 'mathematics', 'fundamentals']
  },
  {
    id: '2',
    title: 'Python Programming Basics',
    description: 'Learn Python from scratch with hands-on examples and exercises',
    type: 'video',
    category: 'Computer Science',
    url: '#',
    author: 'Prof. John Doe',
    createdAt: '2024-10-20',
    downloads: 456,
    rating: 4.9,
    tags: ['python', 'programming', 'beginner']
  },
  {
    id: '3',
    title: 'Biology Study Guide',
    description: 'Complete study guide for AP Biology with practice questions',
    type: 'document',
    category: 'Science',
    url: '#',
    author: 'Dr. Sarah Johnson',
    createdAt: '2024-10-18',
    downloads: 189,
    rating: 4.6,
    tags: ['biology', 'ap', 'study-guide']
  },
  {
    id: '4',
    title: 'World History Timeline',
    description: 'Interactive timeline of major world events from ancient to modern times',
    type: 'article',
    category: 'History',
    url: '#',
    author: 'Prof. Michael Brown',
    createdAt: '2024-10-12',
    downloads: 312,
    rating: 4.7,
    tags: ['history', 'timeline', 'world']
  }
];

const resourceTypes = [
  { value: 'all', label: 'All Resources', icon: BookOpen },
  { value: 'document', label: 'Documents', icon: FileText },
  { value: 'video', label: 'Videos', icon: Video },
  { value: 'article', label: 'Articles', icon: BookOpen }
];

const categories = [
  'All Categories',
  'Mathematics',
  'Computer Science',
  'Science',
  'History',
  'Literature',
  'Languages'
];

export default function ResourcesPage() {
  const [resources, setResources] = useState<Resource[]>(mockResources);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    filterResources();
  }, [searchQuery, selectedType, selectedCategory]);

  const filterResources = () => {
    let filtered = mockResources;

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(resource =>
        resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        resource.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Filter by type
    if (selectedType !== 'all') {
      filtered = filtered.filter(resource => resource.type === selectedType);
    }

    // Filter by category
    if (selectedCategory !== 'All Categories') {
      filtered = filtered.filter(resource => resource.category === selectedCategory);
    }

    setResources(filtered);
  };

  const getResourceIcon = (type: string) => {
    switch (type) {
      case 'document':
        return <FileText className="h-5 w-5 text-blue-600" />;
      case 'video':
        return <Video className="h-5 w-5 text-red-600" />;
      case 'article':
        return <BookOpen className="h-5 w-5 text-green-600" />;
      default:
        return <BookOpen className="h-5 w-5 text-gray-600" />;
    }
  };

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Learning Resources</h1>
            <p className="mt-2 text-gray-600">
              Access study materials, videos, and documents to enhance your learning
            </p>
          </div>

          {/* Search and Filters */}
          <Card className="p-6">
            <div className="space-y-4">
              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search resources..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 py-2 pl-10 pr-4 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Filters */}
              <div className="flex flex-wrap gap-4">
                {/* Type Filter */}
                <div className="flex gap-2">
                  {resourceTypes.map((type) => (
                    <button
                      key={type.value}
                      onClick={() => setSelectedType(type.value)}
                      className={`flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
                        selectedType === type.value
                          ? 'bg-indigo-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      <type.icon className="h-4 w-4" />
                      {type.label}
                    </button>
                  ))}
                </div>

                {/* Category Filter */}
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                >
                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </Card>

          {/* Resources Grid */}
          {loading ? (
            <div className="flex justify-center py-12">
              <div className="h-8 w-8 animate-spin rounded-full border-4 border-indigo-600 border-t-transparent" />
            </div>
          ) : resources.length === 0 ? (
            <Card className="p-12 text-center">
              <BookOpen className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-4 text-lg font-medium text-gray-900">No resources found</h3>
              <p className="mt-2 text-gray-600">Try adjusting your search or filters</p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
              {resources.map((resource) => (
                <Card key={resource.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="p-6">
                    {/* Resource Type Icon */}
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        {getResourceIcon(resource.type)}
                        <div>
                          <span className="text-xs font-medium text-gray-500 uppercase">
                            {resource.type}
                          </span>
                        </div>
                      </div>
                      <button className="text-gray-400 hover:text-yellow-500 transition-colors">
                        <Star className="h-5 w-5" />
                      </button>
                    </div>

                    {/* Title and Description */}
                    <h3 className="mt-4 text-lg font-semibold text-gray-900">
                      {resource.title}
                    </h3>
                    <p className="mt-2 text-sm text-gray-600 line-clamp-2">
                      {resource.description}
                    </p>

                    {/* Tags */}
                    <div className="mt-4 flex flex-wrap gap-2">
                      {resource.tags.map((tag, index) => (
                        <span
                          key={index}
                          className="inline-flex items-center gap-1 rounded-full bg-gray-100 px-2 py-1 text-xs font-medium text-gray-700"
                        >
                          <Tag className="h-3 w-3" />
                          {tag}
                        </span>
                      ))}
                    </div>

                    {/* Metadata */}
                    <div className="mt-4 flex items-center justify-between border-t pt-4">
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <div className="flex items-center gap-1">
                          <Download className="h-4 w-4" />
                          {resource.downloads}
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          {resource.rating}
                        </div>
                      </div>
                      <button className="flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 transition-colors">
                        <Download className="h-4 w-4" />
                        Download
                      </button>
                    </div>

                    {/* Author and Date */}
                    <div className="mt-4 flex items-center justify-between text-xs text-gray-500">
                      <span>{resource.author}</span>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {new Date(resource.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
