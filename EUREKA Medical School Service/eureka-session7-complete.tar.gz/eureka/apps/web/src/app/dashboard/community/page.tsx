'use client';

import { useState } from 'react';
import {
  Users,
  MessageSquare,
  TrendingUp,
  Clock,
  Heart,
  MessageCircle,
  Share2,
  Search,
  Plus,
  Filter,
  Award
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';

interface Post {
  id: string;
  author: {
    name: string;
    avatar: string;
    role: string;
  };
  title: string;
  content: string;
  category: string;
  timestamp: string;
  likes: number;
  comments: number;
  shares: number;
  isLiked: boolean;
  tags: string[];
}

interface StudyGroup {
  id: string;
  name: string;
  description: string;
  members: number;
  maxMembers: number;
  subject: string;
  meetingTime: string;
  isJoined: boolean;
}

const mockPosts: Post[] = [
  {
    id: '1',
    author: {
      name: 'Sarah Chen',
      avatar: '👩‍🎓',
      role: 'Student'
    },
    title: 'Tips for acing your Calculus midterm',
    content: 'Just finished my calc midterm and wanted to share some strategies that really helped me prepare. Focus on understanding concepts rather than memorizing formulas...',
    category: 'Study Tips',
    timestamp: '2 hours ago',
    likes: 45,
    comments: 12,
    shares: 8,
    isLiked: false,
    tags: ['calculus', 'exams', 'study-tips']
  },
  {
    id: '2',
    author: {
      name: 'Michael Torres',
      avatar: '👨‍💻',
      role: 'Teaching Assistant'
    },
    title: 'Office hours this Friday - Python debugging session',
    content: 'Hosting extra office hours this Friday to help with Python debugging techniques. Bring your code questions!',
    category: 'Announcements',
    timestamp: '5 hours ago',
    likes: 23,
    comments: 7,
    shares: 15,
    isLiked: true,
    tags: ['python', 'office-hours', 'debugging']
  },
  {
    id: '3',
    author: {
      name: 'Emily Watson',
      avatar: '👩‍🔬',
      role: 'Student'
    },
    title: 'Looking for study partners for Chemistry',
    content: 'Anyone interested in forming a study group for Organic Chemistry? Planning to meet twice a week...',
    category: 'Study Groups',
    timestamp: '1 day ago',
    likes: 31,
    comments: 18,
    shares: 5,
    isLiked: false,
    tags: ['chemistry', 'study-group', 'collaboration']
  }
];

const mockStudyGroups: StudyGroup[] = [
  {
    id: '1',
    name: 'Calculus Study Squad',
    description: 'Weekly problem-solving sessions for Calculus I & II',
    members: 12,
    maxMembers: 15,
    subject: 'Mathematics',
    meetingTime: 'Tuesdays, 6:00 PM',
    isJoined: true
  },
  {
    id: '2',
    name: 'Python Coders Unite',
    description: 'Learn Python together through collaborative projects',
    members: 8,
    maxMembers: 20,
    subject: 'Computer Science',
    meetingTime: 'Thursdays, 7:00 PM',
    isJoined: false
  },
  {
    id: '3',
    name: 'AP Biology Prep',
    description: 'Preparing for AP Biology exam with practice questions',
    members: 15,
    maxMembers: 15,
    subject: 'Biology',
    meetingTime: 'Sundays, 3:00 PM',
    isJoined: false
  }
];

const categories = ['All', 'Study Tips', 'Announcements', 'Study Groups', 'Questions', 'Resources'];

export default function CommunityPage() {
  const [posts, setPosts] = useState<Post[]>(mockPosts);
  const [studyGroups, setStudyGroups] = useState<StudyGroup[]>(mockStudyGroups);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'discussions' | 'groups'>('discussions');

  const handleLike = (postId: string) => {
    setPosts(posts.map(post =>
      post.id === postId
        ? {
            ...post,
            likes: post.isLiked ? post.likes - 1 : post.likes + 1,
            isLiked: !post.isLiked
          }
        : post
    ));
  };

  const handleJoinGroup = (groupId: string) => {
    setStudyGroups(studyGroups.map(group =>
      group.id === groupId
        ? {
            ...group,
            members: group.isJoined ? group.members - 1 : group.members + 1,
            isJoined: !group.isJoined
          }
        : group
    ));
  };

  const filteredPosts = posts.filter(post => {
    const matchesCategory = selectedCategory === 'All' || post.category === selectedCategory;
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         post.content.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <ProtectedRoute>
      <DashboardLayout>
        <div className="space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Community</h1>
              <p className="mt-2 text-gray-600">
                Connect with peers, join study groups, and share knowledge
              </p>
            </div>
            <button className="flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-700 transition-colors">
              <Plus className="h-5 w-5" />
              New Post
            </button>
          </div>

          {/* Tabs */}
          <Card className="p-4">
            <div className="flex gap-4">
              <button
                onClick={() => setActiveTab('discussions')}
                className={`flex items-center gap-2 rounded-lg px-4 py-2 font-medium transition-colors ${
                  activeTab === 'discussions'
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <MessageSquare className="h-5 w-5" />
                Discussions
              </button>
              <button
                onClick={() => setActiveTab('groups')}
                className={`flex items-center gap-2 rounded-lg px-4 py-2 font-medium transition-colors ${
                  activeTab === 'groups'
                    ? 'bg-indigo-600 text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <Users className="h-5 w-5" />
                Study Groups
              </button>
            </div>
          </Card>

          {/* Search and Filters */}
          <Card className="p-4">
            <div className="flex flex-col gap-4 sm:flex-row">
              {/* Search */}
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search discussions..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 py-2 pl-10 pr-4 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Category Filter */}
              {activeTab === 'discussions' && (
                <div className="flex gap-2 overflow-x-auto">
                  {categories.map((category) => (
                    <button
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className={`whitespace-nowrap rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
                        selectedCategory === category
                          ? 'bg-indigo-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </Card>

          {/* Content Area */}
          {activeTab === 'discussions' ? (
            /* Discussions Feed */
            <div className="space-y-4">
              {filteredPosts.length === 0 ? (
                <Card className="p-12 text-center">
                  <MessageSquare className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-4 text-lg font-medium text-gray-900">No discussions found</h3>
                  <p className="mt-2 text-gray-600">Try adjusting your search or filters</p>
                </Card>
              ) : (
                filteredPosts.map((post) => (
                  <Card key={post.id} className="p-6 hover:shadow-md transition-shadow">
                    {/* Author Info */}
                    <div className="flex items-start gap-4">
                      <div className="text-4xl">{post.author.avatar}</div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="font-semibold text-gray-900">{post.author.name}</h3>
                            <p className="text-sm text-gray-600">{post.author.role}</p>
                          </div>
                          <span className="text-sm text-gray-500">{post.timestamp}</span>
                        </div>

                        {/* Post Content */}
                        <div className="mt-4">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="inline-flex items-center rounded-full bg-indigo-100 px-3 py-1 text-xs font-medium text-indigo-800">
                              {post.category}
                            </span>
                          </div>
                          <h2 className="text-xl font-semibold text-gray-900">{post.title}</h2>
                          <p className="mt-2 text-gray-600">{post.content}</p>

                          {/* Tags */}
                          <div className="mt-3 flex flex-wrap gap-2">
                            {post.tags.map((tag, index) => (
                              <span
                                key={index}
                                className="inline-flex items-center rounded-full bg-gray-100 px-2 py-1 text-xs text-gray-600"
                              >
                                #{tag}
                              </span>
                            ))}
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="mt-4 flex items-center gap-6 border-t pt-4">
                          <button
                            onClick={() => handleLike(post.id)}
                            className={`flex items-center gap-2 text-sm transition-colors ${
                              post.isLiked
                                ? 'text-red-600'
                                : 'text-gray-600 hover:text-red-600'
                            }`}
                          >
                            <Heart className={`h-5 w-5 ${post.isLiked ? 'fill-current' : ''}`} />
                            <span>{post.likes}</span>
                          </button>
                          <button className="flex items-center gap-2 text-sm text-gray-600 hover:text-indigo-600 transition-colors">
                            <MessageCircle className="h-5 w-5" />
                            <span>{post.comments}</span>
                          </button>
                          <button className="flex items-center gap-2 text-sm text-gray-600 hover:text-green-600 transition-colors">
                            <Share2 className="h-5 w-5" />
                            <span>{post.shares}</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))
              )}
            </div>
          ) : (
            /* Study Groups Grid */
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
              {studyGroups.map((group) => (
                <Card key={group.id} className="p-6 hover:shadow-lg transition-shadow">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <Users className="h-8 w-8 text-indigo-600" />
                      <div>
                        <h3 className="font-semibold text-gray-900">{group.name}</h3>
                        <span className="text-sm text-gray-600">{group.subject}</span>
                      </div>
                    </div>
                    {group.isJoined && (
                      <Award className="h-5 w-5 text-green-600" />
                    )}
                  </div>

                  <p className="mt-4 text-sm text-gray-600">{group.description}</p>

                  <div className="mt-4 space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Members</span>
                      <span className="font-medium text-gray-900">
                        {group.members}/{group.maxMembers}
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-indigo-600 h-2 rounded-full"
                        style={{ width: `${(group.members / group.maxMembers) * 100}%` }}
                      />
                    </div>
                  </div>

                  <div className="mt-4 flex items-center gap-2 text-sm text-gray-600">
                    <Clock className="h-4 w-4" />
                    <span>{group.meetingTime}</span>
                  </div>

                  <button
                    onClick={() => handleJoinGroup(group.id)}
                    disabled={!group.isJoined && group.members >= group.maxMembers}
                    className={`mt-6 w-full rounded-lg px-4 py-2 font-medium transition-colors ${
                      group.isJoined
                        ? 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                        : group.members >= group.maxMembers
                        ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                        : 'bg-indigo-600 text-white hover:bg-indigo-700'
                    }`}
                  >
                    {group.isJoined
                      ? 'Leave Group'
                      : group.members >= group.maxMembers
                      ? 'Full'
                      : 'Join Group'}
                  </button>
                </Card>
              ))}
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
