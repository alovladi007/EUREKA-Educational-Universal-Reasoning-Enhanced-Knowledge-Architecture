'use client';

import { useEffect, useRef, useState, useCallback } from 'react';

interface WebSocketMessage {
  type: string;
  [key: string]: any;
}

interface UseWebSocketOptions {
  onMessage?: (message: WebSocketMessage) => void;
  onOpen?: () => void;
  onClose?: () => void;
  onError?: (error: Event) => void;
  reconnect?: boolean;
  reconnectInterval?: number;
}

export function useWebSocket(userId: string, options: UseWebSocketOptions = {}) {
  const {
    onMessage,
    onOpen,
    onClose,
    onError,
    reconnect = true,
    reconnectInterval = 3000
  } = options;

  const wsRef = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<WebSocketMessage | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();

  const connect = useCallback(() => {
    // Connect to WebSocket
    const ws = new WebSocket(`ws://localhost:8000/ws/${userId}`);

    ws.onopen = () => {
      console.log('WebSocket connected');
      setIsConnected(true);
      if (onOpen) onOpen();
      
      // Send heartbeat every 30 seconds
      const heartbeat = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'ping' }));
        }
      }, 30000);
      
      ws.addEventListener('close', () => clearInterval(heartbeat));
    };

    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data) as WebSocketMessage;
        setLastMessage(message);
        if (onMessage) onMessage(message);
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    };

    ws.onclose = () => {
      console.log('WebSocket disconnected');
      setIsConnected(false);
      if (onClose) onClose();

      // Attempt reconnection
      if (reconnect) {
        reconnectTimeoutRef.current = setTimeout(() => {
          console.log('Attempting to reconnect...');
          connect();
        }, reconnectInterval);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      if (onError) onError(error);
    };

    wsRef.current = ws;
  }, [userId, reconnect, reconnectInterval, onMessage, onOpen, onClose, onError]);

  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
  }, []);

  const send = useCallback((message: WebSocketMessage) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message));
    } else {
      console.error('WebSocket is not connected');
    }
  }, []);

  const joinRoom = useCallback((roomId: string) => {
    send({ type: 'join_room', room_id: roomId });
  }, [send]);

  const leaveRoom = useCallback((roomId: string) => {
    send({ type: 'leave_room', room_id: roomId });
  }, [send]);

  const sendChatMessage = useCallback((roomId: string, content: string) => {
    send({
      type: 'chat_message',
      room_id: roomId,
      content
    });
  }, [send]);

  const sendTutorQuery = useCallback((query: string) => {
    send({
      type: 'tutor_query',
      query
    });
  }, [send]);

  const setTyping = useCallback((roomId: string, isTyping: boolean) => {
    send({
      type: 'typing',
      room_id: roomId,
      is_typing: isTyping
    });
  }, [send]);

  useEffect(() => {
    connect();
    return () => disconnect();
  }, [connect, disconnect]);

  return {
    isConnected,
    lastMessage,
    send,
    joinRoom,
    leaveRoom,
    sendChatMessage,
    sendTutorQuery,
    setTyping,
    disconnect
  };
}

// Example usage component
export function LiveChatExample() {
  const userId = 'user123';
  const roomId = 'room456';

  const { isConnected, lastMessage, sendChatMessage, joinRoom, leaveRoom } = useWebSocket(
    userId,
    {
      onMessage: (message) => {
        console.log('Received:', message);
      },
      onOpen: () => {
        console.log('Connected to WebSocket');
      }
    }
  );

  useEffect(() => {
    if (isConnected) {
      joinRoom(roomId);
    }
    return () => {
      if (isConnected) {
        leaveRoom(roomId);
      }
    };
  }, [isConnected, roomId, joinRoom, leaveRoom]);

  const handleSendMessage = () => {
    sendChatMessage(roomId, 'Hello, World!');
  };

  return (
    <div>
      <div>Status: {isConnected ? 'Connected' : 'Disconnected'}</div>
      <button onClick={handleSendMessage} disabled={!isConnected}>
        Send Message
      </button>
      {lastMessage && (
        <div>
          Last message: {lastMessage.type} - {JSON.stringify(lastMessage)}
        </div>
      )}
    </div>
  );
}
