# EUREKA web-grad

## Development

```bash
npm install
npm run dev
```

## API Connection

This app connects to: `http://localhost:800X/api`

See main README for more details.
