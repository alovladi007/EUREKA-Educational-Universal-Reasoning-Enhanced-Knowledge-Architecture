'use client';

import { useEffect, useState } from 'react';
import DashboardLayout from '@/components/layout/DashboardLayout';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import { Card } from '@/components/ui/Card';
import { apiClient } from '@/lib/api-client';
import { BookOpen, Award, TrendingUp, Clock, CheckCircle, Play } from 'lucide-react';

interface Course {
  id: string;
  title: string;
  description: string;
  instructor_name: string;
  progress?: number;
  mastery_level?: number;
  status: string;
  tier: string;
  subject: string;
}

interface Badge {
  id: string;
  name: string;
  description: string;
  icon_url?: string;
  category: string;
  points: number;
  earned_at: string;
}

interface GamePoints {
  total_points: number;
  level: number;
  streak_days: number;
  achievements_count: number;
}

export default function StudentDashboard() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [badges, setBadges] = useState<Badge[]>([]);
  const [gamePoints, setGamePoints] = useState<GamePoints | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);

      // Load enrolled courses
      const enrollmentsResponse = await apiClient.get('/users/me/enrollments');
      setCourses(enrollmentsResponse.data.data || []);

      // Load badges (if available)
      try {
        const badgesResponse = await apiClient.get('/hs/badges/my-badges');
        setBadges(badgesResponse.data.data || []);
      } catch (err) {
        // Badges might not be available yet
        console.log('Badges not available');
      }

      // Load game points (if available)
      try {
        const pointsResponse = await apiClient.get('/hs/points/me');
        setGamePoints(pointsResponse.data);
      } catch (err) {
        // Points might not be available yet
        console.log('Game points not available');
      }
    } catch (error) {
      console.error('Failed to load dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <ProtectedRoute allowedRoles={['student']}>
        <DashboardLayout>
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600" />
          </div>
        </DashboardLayout>
      </ProtectedRoute>
    );
  }

  return (
    <ProtectedRoute allowedRoles={['student']}>
      <DashboardLayout>
        <div className="space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-3xl font-bold text-gray-900">My Dashboard</h1>
            <p className="mt-2 text-sm text-gray-600">
              Welcome back! Here's your learning progress.
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <BookOpen className="h-8 w-8 text-indigo-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Courses</p>
                  <p className="text-2xl font-bold text-gray-900">{courses.length}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Award className="h-8 w-8 text-yellow-500" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Badges Earned</p>
                  <p className="text-2xl font-bold text-gray-900">{badges.length}</p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <TrendingUp className="h-8 w-8 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Points</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {gamePoints?.total_points || 0}
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Clock className="h-8 w-8 text-purple-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Streak Days</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {gamePoints?.streak_days || 0}
                  </p>
                </div>
              </div>
            </Card>
          </div>

          {/* My Courses */}
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4">My Courses</h2>
            {courses.length === 0 ? (
              <Card className="p-8 text-center">
                <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">You're not enrolled in any courses yet.</p>
                <button className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                  Browse Courses
                </button>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {courses.map((course) => (
                  <Card key={course.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="h-32 bg-gradient-to-r from-indigo-500 to-purple-600" />
                    <div className="p-6">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        {course.title}
                      </h3>
                      <p className="text-sm text-gray-600 mb-4 line-clamp-2">
                        {course.description}
                      </p>
                      <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                        <span>{course.instructor_name}</span>
                        <span className="capitalize">{course.subject}</span>
                      </div>

                      {/* Progress Bar */}
                      <div className="mb-4">
                        <div className="flex items-center justify-between text-sm mb-2">
                          <span className="text-gray-600">Progress</span>
                          <span className="font-medium text-gray-900">
                            {Math.round(course.progress || 0)}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-indigo-600 h-2 rounded-full transition-all"
                            style={{ width: `${course.progress || 0}%` }}
                          />
                        </div>
                      </div>

                      {/* Actions */}
                      <button className="w-full flex items-center justify-center px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
                        <Play className="h-4 w-4 mr-2" />
                        Continue Learning
                      </button>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Recent Badges */}
          {badges.length > 0 && (
            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-4">Recent Achievements</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {badges.slice(0, 5).map((badge) => (
                  <Card key={badge.id} className="p-4 text-center hover:shadow-lg transition-shadow">
                    <Award className="h-12 w-12 text-yellow-500 mx-auto mb-2" />
                    <h3 className="font-semibold text-gray-900 mb-1">{badge.name}</h3>
                    <p className="text-xs text-gray-600">{badge.points} points</p>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  );
}
