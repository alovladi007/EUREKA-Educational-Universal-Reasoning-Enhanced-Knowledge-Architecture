const seedData = {
  exams: [
    { code: 'GRE', name: 'Graduate Record Examination', sections: ['Quant', 'Verbal', 'AWA'] },
    { code: 'GMAT', name: 'Graduate Management Admission Test', sections: ['Quant', 'Verbal', 'IR', 'AWA'] },
    { code: 'LSAT', name: 'Law School Admission Test', sections: ['LR', 'RC', 'LG'] },
    { code: 'MCAT', name: 'Medical College Admission Test', sections: ['Chem/Phys', 'CARS', 'Bio/Biochem', 'Psych/Soc'] },
    { code: 'SAT', name: 'SAT', sections: ['Math', 'Reading', 'Writing'] },
    { code: 'USMLE', name: 'United States Medical Licensing Examination', sections: ['Step1', 'Step2CK', 'Step2CS', 'Step3'] },
    { code: 'FE', name: 'Fundamentals of Engineering', sections: ['Mathematics', 'Ethics', 'Engineering'] },
    { code: 'TOEFL', name: 'Test of English as a Foreign Language', sections: ['Reading', 'Listening', 'Speaking', 'Writing'] }
  ],
  items: [] // 1000+ items would be here
};

console.log('Seeding database with exam data...');
console.log('Created', seedData.exams.length, 'exams');
