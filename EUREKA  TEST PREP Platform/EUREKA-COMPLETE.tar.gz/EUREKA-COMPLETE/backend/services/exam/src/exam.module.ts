import { Module } from '@nestjs/common';
import { ExamController } from './exam.controller';
import { AdaptiveService } from './adaptive.service';

@Module({
  controllers: [ExamController],
  providers: [AdaptiveService],
})
export class ExamModule {}
