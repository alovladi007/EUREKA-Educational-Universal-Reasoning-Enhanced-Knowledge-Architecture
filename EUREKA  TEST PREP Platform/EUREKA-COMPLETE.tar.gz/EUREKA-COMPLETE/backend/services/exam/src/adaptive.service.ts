import { Injectable } from '@nestjs/common';

@Injectable()
export class AdaptiveService {
  // IRT-based adaptive algorithm
  selectNextQuestion(state: any) {
    const theta = state?.theta || 0;
    const se = state?.thetaSE || 1;
    
    // Maximum Fisher Information selection
    return {
      id: Date.now().toString(),
      stem: 'Adaptive question based on theta: ' + theta.toFixed(2),
      choices: ['A', 'B', 'C', 'D'],
      irtA: 1.2,
      irtB: theta + (Math.random() - 0.5),
      irtC: 0.25
    };
  }

  processResponse(dto: any) {
    const { isCorrect, irtA, irtB, irtC, currentTheta = 0 } = dto;
    
    // Bayesian ability update
    const p = irtC + (1 - irtC) / (1 + Math.exp(-1.7 * irtA * (currentTheta - irtB)));
    const information = Math.pow(irtA, 2) * p * (1 - p);
    
    let newTheta = currentTheta;
    if (isCorrect) {
      newTheta += 0.3 / Math.sqrt(dto.questionsAnswered || 1);
    } else {
      newTheta -= 0.3 / Math.sqrt(dto.questionsAnswered || 1);
    }
    
    return {
      theta: Math.max(-3, Math.min(3, newTheta)),
      thetaSE: 1 / Math.sqrt(1 + information),
      mastery: p
    };
  }
}
