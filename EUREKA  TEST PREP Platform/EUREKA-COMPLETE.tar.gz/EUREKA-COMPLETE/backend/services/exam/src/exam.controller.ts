import { Controller, Get, Post, Body, Param } from '@nestjs/common';
import { AdaptiveService } from './adaptive.service';

@Controller('api/exam')
export class ExamController {
  constructor(private adaptiveService: AdaptiveService) {}

  @Get('adaptive/next')
  getNextQuestion(@Body() state: any) {
    return this.adaptiveService.selectNextQuestion(state);
  }

  @Post('response')
  submitResponse(@Body() dto: any) {
    return this.adaptiveService.processResponse(dto);
  }

  @Post('start')
  startExam(@Body() dto: any) {
    return { attemptId: Date.now().toString(), examId: dto.examId };
  }
}
