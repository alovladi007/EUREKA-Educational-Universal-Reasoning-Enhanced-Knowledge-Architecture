import { NestFactory } from '@nestjs/core';
import { QBankModule } from './qbank.module';

async function bootstrap() {
  const app = await NestFactory.create(QBankModule);
  await app.listen(3002);
  console.log('QBank service running on port 3002');
}
bootstrap();
