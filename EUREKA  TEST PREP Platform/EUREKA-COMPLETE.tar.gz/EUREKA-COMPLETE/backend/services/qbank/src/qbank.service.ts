import { Injectable } from '@nestjs/common';

@Injectable()
export class QBankService {
  async getItems(query: any) {
    // Mock items with IRT parameters
    return [
      {
        id: '1',
        stem: 'If x^2 = 16, what is x?',
        choices: ['2', '4', '±4', '16'],
        correctIndex: 2,
        irtA: 1.0,
        irtB: -0.5,
        irtC: 0.25,
        difficulty: 'easy'
      }
    ];
  }

  async getItem(id: string) {
    return { id, stem: 'Sample question' };
  }

  async createItem(dto: any) {
    return { ...dto, id: Date.now().toString() };
  }

  async importItems(items: any[]) {
    return { imported: items.length };
  }
}
