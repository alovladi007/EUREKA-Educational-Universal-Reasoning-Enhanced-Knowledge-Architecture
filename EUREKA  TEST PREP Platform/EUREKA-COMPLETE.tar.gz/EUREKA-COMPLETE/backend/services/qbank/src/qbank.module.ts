import { Module } from '@nestjs/common';
import { QBankController } from './qbank.controller';
import { QBankService } from './qbank.service';

@Module({
  controllers: [QBankController],
  providers: [QBankService],
})
export class QBankModule {}
