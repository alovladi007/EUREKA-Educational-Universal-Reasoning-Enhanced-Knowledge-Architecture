import { Controller, Get, Post, Body, Param, Query } from '@nestjs/common';
import { QBankService } from './qbank.service';

@Controller('api/qbank')
export class QBankController {
  constructor(private qbankService: QBankService) {}

  @Get('items')
  getItems(@Query() query: any) {
    return this.qbankService.getItems(query);
  }

  @Get('items/:id')
  getItem(@Param('id') id: string) {
    return this.qbankService.getItem(id);
  }

  @Post('items')
  createItem(@Body() dto: any) {
    return this.qbankService.createItem(dto);
  }

  @Post('import')
  importItems(@Body() items: any[]) {
    return this.qbankService.importItems(items);
  }
}
