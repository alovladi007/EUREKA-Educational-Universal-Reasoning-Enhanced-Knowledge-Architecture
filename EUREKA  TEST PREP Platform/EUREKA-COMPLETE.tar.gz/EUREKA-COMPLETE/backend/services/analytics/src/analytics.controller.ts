import { Controller, Get, Query } from '@nestjs/common';
import { AnalyticsService } from './analytics.service';

@Controller('api/analytics')
export class AnalyticsController {
  constructor(private analyticsService: AnalyticsService) {}

  @Get('readiness')
  getReadiness() {
    return this.analyticsService.calculateReadiness();
  }

  @Get('mastery')
  getMastery() {
    return this.analyticsService.getTopicMastery();
  }

  @Get('progress')
  getProgress(@Query('days') days: number) {
    return this.analyticsService.getProgress(days);
  }
}
