import { Injectable } from '@nestjs/common';

@Injectable()
export class AnalyticsService {
  calculateReadiness() {
    return {
      score: 72,
      percentile: 85,
      confidence: 0.82,
      projection: { min: 155, expected: 162, max: 168 }
    };
  }

  getTopicMastery() {
    return [
      { topic: 'Algebra', mastery: 0.85, trend: 'up' },
      { topic: 'Geometry', mastery: 0.62, trend: 'stable' },
      { topic: 'Verbal', mastery: 0.70, trend: 'up' }
    ];
  }

  getProgress(days: number) {
    return {
      questionsAnswered: 450,
      accuracyTrend: [0.65, 0.68, 0.71, 0.73, 0.75],
      timePerQuestion: [95, 88, 82, 78, 75]
    };
  }
}
