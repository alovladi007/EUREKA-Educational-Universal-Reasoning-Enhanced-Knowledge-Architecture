import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';

@Injectable()
export class AuthService {
  constructor(private jwtService: JwtService) {}

  async register(dto: any) {
    const hashedPassword = await bcrypt.hash(dto.password, 10);
    // Save to database (mock)
    return { message: 'User registered', email: dto.email };
  }

  async login(dto: any) {
    // Validate user (mock)
    const payload = { email: dto.email, sub: 'user-id' };
    return {
      access_token: this.jwtService.sign(payload),
    };
  }
}
