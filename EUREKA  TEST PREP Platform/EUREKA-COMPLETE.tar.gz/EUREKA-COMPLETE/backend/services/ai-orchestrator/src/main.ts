import { NestFactory } from '@nestjs/core';
import { AIModule } from './ai.module';

async function bootstrap() {
  const app = await NestFactory.create(AIModule);
  await app.listen(3009);
  console.log('AI Orchestrator running on port 3009');
}
bootstrap();
