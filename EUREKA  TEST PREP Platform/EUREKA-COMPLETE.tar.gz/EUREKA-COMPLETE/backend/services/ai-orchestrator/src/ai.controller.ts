import { Controller, Post, Body } from '@nestjs/common';
import { AIService } from './ai.service';

@Controller('api/ai')
export class AIController {
  constructor(private aiService: AIService) {}

  @Post('explain')
  explainItem(@Body() dto: any) {
    return this.aiService.generateExplanation(dto);
  }

  @Post('generate')
  generateItems(@Body() dto: any) {
    return this.aiService.generateQuestions(dto);
  }

  @Post('feedback')
  provideFeedback(@Body() dto: any) {
    return this.aiService.generateFeedback(dto);
  }
}
