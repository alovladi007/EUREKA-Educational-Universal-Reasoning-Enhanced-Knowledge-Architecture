# EUREKA Test Prep Platform

## Complete Implementation

This is the complete EUREKA Test Prep platform with:

### Backend Services
- Auth Service (JWT authentication)
- QBank Service (Question management)
- Exam Service (Adaptive testing engine)
- Analytics Service (Performance tracking)
- AI Orchestrator (LLM integration)
- Plus 4 more services

### Frontend
- Next.js 14 with TypeScript
- Responsive UI with Tailwind CSS
- Real-time analytics dashboards
- Adaptive practice interface

### Infrastructure
- Docker Compose setup
- PostgreSQL with pgvector
- Redis caching
- TimescaleDB for analytics
- Weaviate vector database
- MinIO object storage

## Quick Start

1. Install dependencies:
```bash
cd backend && npm install
cd ../frontend && npm install
```

2. Start backend:
```bash
cd backend
docker-compose up -d
npm run migrate
npm run seed
```

3. Start frontend:
```bash
cd frontend
npm run dev
```

Access at http://localhost:3000

## Features
- IRT-based adaptive learning
- AI-powered explanations
- Real-time performance tracking
- Multi-exam support (GRE, GMAT, LSAT, MCAT, etc.)
- Proctoring capabilities
- Study planning
- Community features

## License
MIT
