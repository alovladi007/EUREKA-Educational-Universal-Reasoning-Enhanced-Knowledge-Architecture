export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-indigo-50 to-white">
      <div className="max-w-7xl mx-auto px-4 py-16">
        <h1 className="text-5xl font-bold text-center text-gray-900 mb-4">
          EUREKA Test Prep
        </h1>
        <p className="text-xl text-center text-gray-600 mb-8">
          AI-Powered Adaptive Learning for Standardized Tests
        </p>
        <div className="flex justify-center gap-4">
          <a href="/dashboard" className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
            Get Started
          </a>
          <a href="/demo" className="px-6 py-3 bg-white text-indigo-600 border border-indigo-600 rounded-lg hover:bg-indigo-50">
            Try Demo
          </a>
        </div>
      </div>
    </main>
  )
}
