import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost/api';

export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Auth
export const auth = {
  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }),
  register: (data: any) => api.post('/auth/register', data),
  profile: () => api.get('/auth/profile'),
};

// QBank
export const qbank = {
  getItems: (params?: any) => api.get('/qbank/items', { params }),
  getItem: (id: string) => api.get(`/qbank/items/${id}`),
};

// Exam
export const exam = {
  getNextQuestion: () => api.get('/exam/adaptive/next'),
  submitResponse: (data: any) => api.post('/exam/response', data),
  startExam: (examId: string) => api.post('/exam/start', { examId }),
};

// Analytics
export const analytics = {
  getReadiness: () => api.get('/analytics/readiness'),
  getMastery: () => api.get('/analytics/mastery'),
  getProgress: (days: number) => api.get('/analytics/progress', { params: { days } }),
};
