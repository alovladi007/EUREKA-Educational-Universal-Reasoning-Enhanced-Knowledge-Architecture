/**
 * EUREKA API Client
 * 
 * Handles all API requests with authentication and error handling
 */

import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import type { 
  User, Organization, Course, Enrollment, Badge,
  LoginRequest, RegisterRequest, AuthResponse
} from '@/types';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';
const API_PREFIX = process.env.NEXT_PUBLIC_API_PREFIX || '/api/v1';

class ApiClient {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: `${API_URL}${API_PREFIX}`,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    // Request interceptor - add auth token
    this.client.interceptors.request.use(
      (config) => {
        const token = this.getToken();
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    // Response interceptor - handle token refresh
    this.client.interceptors.response.use(
      (response) => response,
      async (error) => {
        const originalRequest = error.config;

        // If 401 and not already retried, try to refresh token
        if (error.response?.status === 401 && !originalRequest._retry) {
          originalRequest._retry = true;

          try {
            const refreshToken = this.getRefreshToken();
            if (refreshToken) {
              const response = await axios.post(
                `${API_URL}${API_PREFIX}/auth/refresh`,
                { refresh_token: refreshToken }
              );
              
              const { access_token } = response.data;
              this.setToken(access_token);
              
              originalRequest.headers.Authorization = `Bearer ${access_token}`;
              return this.client(originalRequest);
            }
          } catch (refreshError) {
            this.clearTokens();
            window.location.href = '/auth/login';
            return Promise.reject(refreshError);
          }
        }

        return Promise.reject(error);
      }
    );
  }

  // Token management
  private getToken(): string | null {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem('access_token');
  }

  private getRefreshToken(): string | null {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem('refresh_token');
  }

  setToken(token: string) {
    if (typeof window !== 'undefined') {
      localStorage.setItem('access_token', token);
    }
  }

  setRefreshToken(token: string) {
    if (typeof window !== 'undefined') {
      localStorage.setItem('refresh_token', token);
    }
  }

  clearTokens() {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('access_token');
      localStorage.removeItem('refresh_token');
    }
  }

  // ==================== Auth ====================

  async login(data: LoginRequest): Promise<AuthResponse> {
    const response = await this.client.post<AuthResponse>('/auth/login', data);
    this.setToken(response.data.access_token);
    this.setRefreshToken(response.data.refresh_token);
    return response.data;
  }

  async register(data: RegisterRequest): Promise<AuthResponse> {
    const response = await this.client.post<AuthResponse>('/auth/register', data);
    this.setToken(response.data.access_token);
    this.setRefreshToken(response.data.refresh_token);
    return response.data;
  }

  async logout(): Promise<void> {
    try {
      await this.client.post('/auth/logout');
    } finally {
      this.clearTokens();
    }
  }

  async getCurrentUser(): Promise<User> {
    const response = await this.client.get<User>('/auth/me');
    return response.data;
  }

  async refreshAccessToken(refreshToken: string): Promise<{ access_token: string }> {
    const response = await this.client.post('/auth/refresh', { refresh_token: refreshToken });
    this.setToken(response.data.access_token);
    return response.data;
  }

  // ==================== Users ====================

  async getMyProfile(): Promise<User> {
    const response = await this.client.get<User>('/users/me');
    return response.data;
  }

  async updateMyProfile(data: Partial<User>): Promise<User> {
    const response = await this.client.patch<User>('/users/me', data);
    return response.data;
  }

  async getMyEnrollments(): Promise<Enrollment[]> {
    const response = await this.client.get<Enrollment[]>('/users/me/enrollments');
    return response.data;
  }

  // ==================== Organizations ====================

  async getOrganizations(params?: { 
    skip?: number; 
    limit?: number; 
    tier?: string;
    is_active?: boolean;
    search?: string;
  }): Promise<{ items: Organization[]; total: number }> {
    const response = await this.client.get('/organizations', { params });
    return response.data;
  }

  async getOrganization(id: string): Promise<Organization> {
    const response = await this.client.get<Organization>(`/organizations/${id}`);
    return response.data;
  }

  // ==================== Courses ====================

  async getCourses(params?: {
    skip?: number;
    limit?: number;
    tier?: string;
    is_published?: boolean;
    is_archived?: boolean;
    instructor_id?: string;
    subject?: string;
    search?: string;
  }): Promise<{ items: Course[]; total: number }> {
    const response = await this.client.get('/courses', { params });
    return response.data;
  }

  async getCourse(id: string): Promise<Course> {
    const response = await this.client.get<Course>(`/courses/${id}`);
    return response.data;
  }

  async createCourse(data: Partial<Course>): Promise<Course> {
    const response = await this.client.post<Course>('/courses', data);
    return response.data;
  }

  async updateCourse(id: string, data: Partial<Course>): Promise<Course> {
    const response = await this.client.patch<Course>(`/courses/${id}`, data);
    return response.data;
  }

  async publishCourse(id: string): Promise<Course> {
    const response = await this.client.post<Course>(`/courses/${id}/publish`);
    return response.data;
  }

  async unpublishCourse(id: string): Promise<Course> {
    const response = await this.client.post<Course>(`/courses/${id}/unpublish`);
    return response.data;
  }

  async deleteCourse(id: string): Promise<void> {
    await this.client.delete(`/courses/${id}`);
  }

  // ==================== Enrollments ====================

  async enrollInCourse(courseId: string, userId?: string): Promise<Enrollment> {
    const response = await this.client.post<Enrollment>(
      `/courses/${courseId}/enroll`,
      userId ? { user_id: userId } : undefined
    );
    return response.data;
  }

  async getCourseEnrollments(courseId: string, params?: {
    skip?: number;
    limit?: number;
    status?: string;
  }): Promise<{ items: Enrollment[]; total: number }> {
    const response = await this.client.get(`/courses/${courseId}/enrollments`, { params });
    return response.data;
  }

  async updateEnrollment(
    courseId: string, 
    userId: string, 
    data: Partial<Enrollment>
  ): Promise<Enrollment> {
    const response = await this.client.patch<Enrollment>(
      `/courses/${courseId}/enrollments/${userId}`,
      data
    );
    return response.data;
  }

  async unenrollFromCourse(courseId: string, userId: string): Promise<void> {
    await this.client.delete(`/courses/${courseId}/enrollments/${userId}`);
  }

  // ==================== Badges (High School Tier) ====================

  async getBadges(params?: {
    skip?: number;
    limit?: number;
    category?: string;
  }): Promise<{ items: Badge[]; total: number }> {
    const response = await this.client.get('/tier-hs/badges', { params });
    return response.data;
  }

  async getUserBadges(userId: string): Promise<Badge[]> {
    const response = await this.client.get(`/tier-hs/users/${userId}/badges`);
    return response.data;
  }

  async getMyBadges(): Promise<Badge[]> {
    const response = await this.client.get('/tier-hs/me/badges');
    return response.data;
  }
}

// Export singleton instance
export const apiClient = new ApiClient();
export default apiClient;
